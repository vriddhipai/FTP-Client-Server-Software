import java.net.*;
import java.io.*;
import java.nio.*;
import java.nio.channels.*;
import java.util.*;
import java.util.Scanner;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Client1 {

	Socket requestSocket;          //socket connect to the server
	ObjectOutputStream out;         //stream write to the socket
        FileOutputStream fout;
        FileInputStream fin;
        BufferedOutputStream bos;
        OutputStream ops;
        InputStream ips;
        BufferedInputStream bin;
 	ObjectInputStream in;          //stream read from the socket
	String message;                //message send to the server
	String serverResponse;         //files in directory message read from the server
	String showFile;	       // get command files read from the server
	public final static String ReceivedFile = "C:/Users/vridd/Desktop/";
        int count;
        int cur;
	public void Client1() {}

	void run() throws ClassNotFoundException
	{
		try{
			//create a socket to connect to the server
			requestSocket = new Socket("localhost", 8000);
			System.out.println("Connected to localhost in port 8000");
			//initialize inputStream and outputStream
			out = new ObjectOutputStream(requestSocket.getOutputStream());
			out.flush();
			in = new ObjectInputStream(requestSocket.getInputStream());
			//get Input from standard input
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
			while(true)
			{
				Scanner sc = new Scanner(System.in);
				System.out.println("Please input ftp commands: ");
				String message = sc.nextLine();
				String [] split = message.split(" ");
				switch(split[0])
				{
					case "dir":
					{
						try{
							//stream write the message
							out.writeObject(message);
							out.flush();
						}
						catch(IOException ioException){
							ioException.printStackTrace();
						}
						serverResponse = (String)in.readObject();
						System.out.println(serverResponse);

						break;
					}


					case "get":
					{
						try{
							//stream write the message
							out.writeObject(message);
							out.flush();
						}
						catch(IOException ioException){
							ioException.printStackTrace();
						}
						String found = (String)in.readObject();
						if(found.equals("File not present")) {
							System.out.println("File is not present on server");
							break;
						}
					    download(split[1]);
							break;
					}


					case "upload":
					{
						upload(split[1]);
						break;

					}

          				default:
					{
						System.out.println("Unknown command! Please try again! ");
						break;
					}
				}


		}
	}

		catch (ConnectException e) {
    			System.err.println("Connection refused. You need to initiate a server first.");
		}
		catch(UnknownHostException unknownHost){
			System.err.println("You are trying to connect to an unknown host!");
		}
		catch(IOException ioException){
		}
		finally{
			//Close connections
			try{
				in.close();
				out.close();
				requestSocket.close();
			}
			catch(IOException ioException){
			}
		}
	}
	//send a message to the output stream
	void sendMessage(String msg)
	{
		try{
			//stream write the message
			out.writeObject(msg);
			out.flush();
		}
		catch(IOException ioException){
			ioException.printStackTrace();
		}
	}


	
	public static boolean connection()
	{
		Scanner sc = new Scanner(System.in);
		String host;
		int port;
                       
			host = sc.nextLine();
			port= sc.nextInt();
                   
			if(!host.equals("localhost") || port!=8000)
			{
				System.out.println("Wrong client or portname! Disconnecting... ");
				return false;
			}
				
		return((host.equals("localhost") || host.equals("127.0.0.1")) && (port == 8000));
		
	}



    //main method
	public static void main(String args[])throws ClassNotFoundException
	{
            while(true)
            {
                Scanner sc = new Scanner(System.in);
			System.out.println("Please input ftp commands: ");
			String username = "Vriddhi";
			String password = "Pai";
                        String uname= "";
                        String pass= "";
			String command = sc.nextLine();
			switch(command)
			{
			case "ftpclient":
			{
					boolean decision= connection();
					if(decision == true)
					{
						
						System.out.println("Enter username: ");
						uname = sc.nextLine();
						System.out.println("Enter password: ");
						pass = sc.nextLine();
						if(uname.equals(username) && pass.equals(password))
						{
							Client1 client = new Client1();
							client.run();
						}
					else
					{
						System.out.println("Authentication failed! Reconnect and try again!");
						
					}


                                        }
                                        

                        }
				
			default:
			{
				System.out.println("Please use 'ftpclient'command to log in first! ");
                                break;
			}
                                  

            }
			
       }

}



			
                                

			
				
		

			void download(String file) throws IOException
			{
				int c;
				BufferedOutputStream bos = null;
				try {
				InputStream ips = requestSocket.getInputStream();
				bos = new BufferedOutputStream(new FileOutputStream("C:/Users/vridd/desktop/ftp/ftp_client1/"+ file));
				byte[] myarray = new byte[1024*16];
				while((c = ips.read(myarray))>0)
				{
					bos.write(myarray, 0, c);
				}
				bos.flush();
				System.out.println("file recieved");
			}
				finally
				{
						//if(bos != null)
						bos.close();
						//connection.close();
				}
			}

			void upload(String file)throws FileNotFoundException, IOException
			{
				BufferedInputStream bis=null;
				OutputStream ops= null;
				File f;
				try
				{
                                    try
                                    {
					
						f = new File(file);
						bis = new BufferedInputStream(new FileInputStream(f));
						out.writeObject("upload " + file);

                                    }
                                    catch(FileNotFoundException err)
				{
					out.writeObject("File not present");
                                        
				}
				ops = requestSocket.getOutputStream();
				byte[] myarray = new byte[1024*16];
				bis.read(myarray, 0, myarray.length);
				System.out.println("uploading");
				ops.write(myarray, 0, myarray.length);
				ops.flush();
				System.out.println("File uploaded to server");
			}
                         catch(FileNotFoundException err)
			{
					out.writeObject("File not present");
                                        
			}
			finally
			{
				bis.close();
				ops.close();
				//connection.close();
			}
                        

                        }

}

