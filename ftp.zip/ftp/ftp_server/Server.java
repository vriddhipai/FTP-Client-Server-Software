import java.net.*;
import java.io.*;
import java.nio.*;
import java.nio.channels.*;
import java.util.*;

public class Server
 {

	private static final int sPort = 8000;   //The server will be listening on this port number

	
		public static void main(String[] args) throws Exception
	{
		System.out.println("The server is running.");
        	ServerSocket listener = new ServerSocket(sPort);
		int clientNum = 1;
        	try {
            		while(true) {
                		new Handler(listener.accept(),clientNum).start();
				System.out.println("Client "  + clientNum + " is connected!");
				clientNum++;
                    }
        	} finally {
            		listener.close();
        	}

        }

	/**
     	* A handler thread class.  Handlers are spawned from the listening
     	* loop and are responsible for dealing with a single client's requests.
     	*/
    	private static class Handler extends Thread {
        	private String message;    //message received from the client
		private String MESSAGE;    //uppercase message send to the client
		private Socket connection;
        	private ObjectInputStream in;	//stream read from the socket
        	private ObjectOutputStream out;    //stream write to the socket
		private int no;		//The index number of the client

        	public Handler(Socket connection, int no) {
                    
            		this.connection = connection;
	    		this.no = no;
        	}

  public void run()
{
 		try
		{
			//initialize Input and Output streams
			out = new ObjectOutputStream(connection.getOutputStream());
			out.flush();
			in = new ObjectInputStream(connection.getInputStream());
			try
			{
				while(true)
				{
						message = (String)in.readObject();
						String[] split = message.split(" ");
						String list_of_files = " ";
						switch(split[0])
						{
							case "dir":
							{
								list_of_files = filenames();
								try
								{
									out.writeObject(list_of_files);
									out.flush();
									System.out.println("Sending list of files to client" +no);
								}
								catch(IOException ioException)
								{
									ioException.printStackTrace();
								}
								break;
						}

							case "get":
							{
								download(split[1]);
								break;
							}
							case "upload":
							{
								uploading(split[1]);
								break;
							}
						}
				}
			}
			catch(ClassNotFoundException classnot){
					System.err.println("Data received in unknown format");
				}
		}
		catch(IOException ioException){
			System.out.println("Disconnect with Client " + no);
		}

		finally{
			//Close connections
			try{
				in.close();
				out.close();
				connection.close();
			}
			catch(IOException ioException){
				System.out.println("Disconnect with Client " + no);
			}
		}
	}


	public String filenames() throws IOException
	{
		String directory = new java.io.File(".").getCanonicalPath();
		File folder = new File(directory);
			File[] filelist = folder.listFiles();
			String filenames="";
			for(File file: filelist)
			{
				filenames+= " \n " +file.getName();
			}
			 return filenames;
	}

 void download(String file) throws IOException
	{
			OutputStream ops = null;
			BufferedInputStream bis = null;
			File f;
			try {
			try {
			f = new File(file);
		 	bis = new BufferedInputStream(new FileInputStream(f));
			out.writeObject("File is present");
			}
			catch(FileNotFoundException ex)
			{
				out.writeObject("File not present");

			}
			 ops = connection.getOutputStream();
			byte[] myarray = new byte[1024*16];
			bis.read(myarray, 0, myarray.length);
			ops.write(myarray, 0, myarray.length);
			ops.flush();
			System.out.println("Sent file to client"+ no);
		}
                        
                catch(Exception e)
                {
                    
                }
		finally
		{
				bis.close();
				ops.close();
		}
	}
	 void uploading(String file) throws IOException
	{
    		System.out.println("Uploading");
		BufferedOutputStream bos = null;
		int c;

		try
		{
			InputStream ips = connection.getInputStream();
		 	bos = new BufferedOutputStream(new FileOutputStream("C:/Users/vridd/desktop/ftp/ftp_server/"+ file));
			byte[] myarray = new byte[16*1024];

			while((c = ips.read(myarray))>0)
			{
				bos.write(myarray, 0, c);
			}
			bos.flush();
    			System.out.println("File recieved");
		}
                catch(Exception e)
                {
                    
                }
		finally
		{
    			if(bos != null)
			bos.close();
	   	}
	}

    }
}
